package com.codewithmosh.streams;

public class StreamsDemo {
  public static void show() {
  }
}
